# empires_revisited
A Minecraft datapack that encourages city-building and strategy.
